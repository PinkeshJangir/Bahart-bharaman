# BHARAT_DARSAAN

**Introduction
BHARAT_DARSAAN is project of making a system to combine the travelling , Home stay , Biking Community and many more in one place where user can take help from thie in his trip.
About the project
In this project, we aim to develop a user friendly website which can help user in their trip by providing such kinding of features and healping them in their stay and travelling or conect them with riders and unexplored places with the help of bloggers and also provide Random trip where user have to give some information like budget , age , name , and some normal questions then we plan a random trip for that person .

###🚀 Languages and Tools Used:

  <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> <img src="https://img.icons8.com/color/48/000000/javascript.png"/> </a> 
    <a href="https://www.w3.org/html/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/html-5.png"/> </a> 
    <a href="https://www.w3schools.com/css/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/css3.png"/> </a>  
    <a style="padding-right:8px;" href="https://nodejs.org" target="_blank"> <img src="https://img.icons8.com/color/48/000000/nodejs.png"/> </a> 
    <a href="https://git-scm.com/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/git.png"/> </a>



**Contributors:

Rishkish Mishra - Bussiness.

Jaiyshanu - Bussiness.

Ankush Verma - Website Development.

Amitabh Sharma - Website Development.
